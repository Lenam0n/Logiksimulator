﻿using System.Runtime.CompilerServices;

class UND : GATTER
{

    private AUSGANG Y;
    private EINGANG a1;
    private EINGANG a2;

    public UND()
    {
        Y = new AUSGANG(this);
        a1 = new EINGANG(this);
        a2 = new EINGANG(this);
    }
    public bool schalten() { return true; }

    public void addEingang(EINGANG e) { }
    public void addAusgang(AUSGANG a) { }
    public AUSGANG getAusgang() { return null; }
    public EINGANG getEingang() { return null; }
    public EINGANG getEingang(int e = 0) { return null; }

    public void setConnector(CONNECTOR c) { }

    /*
    public bool schalten()
    {
        int anz = E.Count;

        Y = true;

        if (anz < 2)
            Console.WriteLine("Die Liste muss mindestens 2 Parameter haben!");
        else  
            foreach(bool b in E)
            {
                if (!b)
                {
                    Y = false;
                    break;
                }                
            }
        

        return Y;
    }
    */

}